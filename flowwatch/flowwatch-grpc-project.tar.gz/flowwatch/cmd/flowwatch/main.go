package main

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"connectrpc.com/cors"
	"golang.org/x/net/http2"
	"golang.org/x/net/http2/h2c"

	"github.com/yourorg/flowwatch/internal/server"
)

func main() {
	logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))
	slog.SetDefault(logger)

	addr := envOr("FLOWWATCH_ADDR", ":8090")

	mux := http.NewServeMux()

	// Register all Connect-Go service handlers on the mux.
	// Each handler registers its own path prefix (e.g., /flowwatch.v1.RunService/).
	server.RegisterAll(mux)

	// Serve the OpenAPI spec for Redocly dev mode.
	mux.Handle("/docs/", http.StripPrefix("/docs/", http.FileServer(http.Dir("docs"))))

	// Health check
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		fmt.Fprintln(w, "ok")
	})

	// Wrap with CORS for browser Connect/gRPC-Web clients.
	handler := withCORS(mux)

	// h2c allows HTTP/2 without TLS (for local dev + gRPC).
	srv := &http.Server{
		Addr:    addr,
		Handler: h2c.NewHandler(handler, &http2.Server{}),
	}

	// Graceful shutdown
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go func() {
		slog.Info("flowwatch server starting", "addr", addr)
		slog.Info("API docs available", "url", fmt.Sprintf("http://localhost%s/docs/", addr))
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			slog.Error("server error", "err", err)
			os.Exit(1)
		}
	}()

	<-ctx.Done()
	slog.Info("shutting down...")

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		slog.Error("shutdown error", "err", err)
	}
}

func envOr(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

// withCORS wraps a handler to allow browser-based Connect and gRPC-Web requests.
func withCORS(h http.Handler) http.Handler {
	return cors.New(cors.Options{
		AllowedMethods: cors.AllowedMethods(),
		AllowedHeaders: cors.AllowedHeaders(),
		ExposedHeaders: cors.ExposedHeaders(),
	}).Handler(h)
}
