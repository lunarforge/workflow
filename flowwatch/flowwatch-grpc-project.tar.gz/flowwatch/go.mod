module github.com/yourorg/flowwatch

go 1.23

require (
	connectrpc.com/connect v1.18.1
	connectrpc.com/cors v0.1.0
	golang.org/x/net v0.34.0
	google.golang.org/protobuf v1.36.4
)
