package server

import (
	"context"
	"log/slog"
	"time"

	"connectrpc.com/connect"
)

// NewLoggingInterceptor returns a Connect interceptor that logs every RPC call
// with method, duration, and error status.
func NewLoggingInterceptor() connect.UnaryInterceptorFunc {
	return func(next connect.UnaryFunc) connect.UnaryFunc {
		return func(ctx context.Context, req connect.AnyRequest) (connect.AnyResponse, error) {
			start := time.Now()
			resp, err := next(ctx, req)
			dur := time.Since(start)

			attrs := []any{
				"method", req.Spec().Procedure,
				"duration_ms", dur.Milliseconds(),
			}
			if err != nil {
				attrs = append(attrs, "error", err.Error())
				slog.WarnContext(ctx, "rpc.error", attrs...)
			} else {
				slog.InfoContext(ctx, "rpc.ok", attrs...)
			}
			return resp, err
		}
	}
}
