package server

import (
	"net/http"

	"connectrpc.com/connect"
)

// RegisterAll mounts all FlowWatch service handlers onto the given mux.
// Each Connect-Go handler registers at its canonical path prefix.
//
// In production, inject real EngineAdapter and SearchIndex implementations.
// For development, use in-memory stubs.
func RegisterAll(mux *http.ServeMux) {
	// Interceptors shared across all services (logging, auth, metrics).
	interceptors := connect.WithInterceptors(
		NewLoggingInterceptor(),
		// NewAuthInterceptor(authConfig),
		// NewMetricsInterceptor(promRegistry),
	)

	// ─── WorkflowService ───
	// Path: /flowwatch.v1.WorkflowService/
	workflowPath, workflowHandler := NewWorkflowServiceHandler(interceptors)
	mux.Handle(workflowPath, workflowHandler)

	// ─── RunService ───
	// Path: /flowwatch.v1.RunService/
	runPath, runHandler := NewRunServiceHandler(interceptors)
	mux.Handle(runPath, runHandler)

	// ─── SearchService ───
	// Path: /flowwatch.v1.SearchService/
	searchPath, searchHandler := NewSearchServiceHandler(interceptors)
	mux.Handle(searchPath, searchHandler)

	// ─── AnalyticsService ───
	// Path: /flowwatch.v1.AnalyticsService/
	analyticsPath, analyticsHandler := NewAnalyticsServiceHandler(interceptors)
	mux.Handle(analyticsPath, analyticsHandler)

	// ─── StreamService ───
	// Path: /flowwatch.v1.StreamService/
	streamPath, streamHandler := NewStreamServiceHandler(interceptors)
	mux.Handle(streamPath, streamHandler)
}
