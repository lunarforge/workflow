package server

// This file contains placeholder handler constructors.
//
// After running `buf generate`, Connect-Go will produce handler interfaces in:
//   gen/flowwatch/v1/flowwatchv1connect/
//
// Each NewXxxServiceHandler function should:
//   1. Accept dependencies (EngineAdapter, SearchIndex, etc.)
//   2. Return (path string, handler http.Handler) via the generated constructor
//
// Example (after codegen):
//
//   import (
//       flowwatchv1connect "github.com/yourorg/flowwatch/gen/flowwatch/v1/flowwatchv1connect"
//   )
//
//   type workflowServiceServer struct {
//       adapter adapter.EngineAdapter
//   }
//
//   func (s *workflowServiceServer) ListWorkflows(
//       ctx context.Context,
//       req *connect.Request[flowwatchv1.ListWorkflowsRequest],
//   ) (*connect.Response[flowwatchv1.ListWorkflowsResponse], error) {
//       workflows, err := s.adapter.ListWorkflows(ctx)
//       // ... map to proto and return
//   }
//
//   func NewWorkflowServiceHandler(opts ...connect.HandlerOption) (string, http.Handler) {
//       return flowwatchv1connect.NewWorkflowServiceHandler(
//           &workflowServiceServer{adapter: myAdapter},
//           opts...,
//       )
//   }

import (
	"net/http"

	"connectrpc.com/connect"
)

// ─── Placeholder constructors ───
// Replace these with real implementations after running `buf generate`.

func NewWorkflowServiceHandler(opts ...connect.HandlerOption) (string, http.Handler) {
	return "/flowwatch.v1.WorkflowService/", http.NotFoundHandler()
}

func NewRunServiceHandler(opts ...connect.HandlerOption) (string, http.Handler) {
	return "/flowwatch.v1.RunService/", http.NotFoundHandler()
}

func NewSearchServiceHandler(opts ...connect.HandlerOption) (string, http.Handler) {
	return "/flowwatch.v1.SearchService/", http.NotFoundHandler()
}

func NewAnalyticsServiceHandler(opts ...connect.HandlerOption) (string, http.Handler) {
	return "/flowwatch.v1.AnalyticsService/", http.NotFoundHandler()
}

func NewStreamServiceHandler(opts ...connect.HandlerOption) (string, http.Handler) {
	return "/flowwatch.v1.StreamService/", http.NotFoundHandler()
}
